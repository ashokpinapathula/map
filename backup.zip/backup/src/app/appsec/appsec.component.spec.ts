import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppsecComponent } from './appsec.component';

describe('AppsecComponent', () => {
  let component: AppsecComponent;
  let fixture: ComponentFixture<AppsecComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppsecComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AppsecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
