import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appsec',
  templateUrl: './appsec.component.html',
  styleUrls: ['./appsec.component.css']
})
export class AppsecComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
